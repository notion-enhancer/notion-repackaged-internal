"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = require("./config.json");
exports.default = config;
